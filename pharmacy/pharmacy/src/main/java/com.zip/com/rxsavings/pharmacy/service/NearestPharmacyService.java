package com.rxsavings.pharmacy.service;

import com.rxsavings.pharmacy.model.dto.NearestPharmacyDTO;
import com.rxsavings.pharmacy.model.vo.CoordinatesVO;

public interface NearestPharmacyService {

    NearestPharmacyDTO findNearestPharmacy(CoordinatesVO coordinatesVO);
}
