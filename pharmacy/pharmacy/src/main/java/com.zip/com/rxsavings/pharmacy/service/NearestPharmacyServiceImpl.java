package com.rxsavings.pharmacy.service;

import com.rxsavings.pharmacy.model.dto.NearestPharmacyDTO;
import com.rxsavings.pharmacy.model.entity.NearestPharmacyEntity;
import com.rxsavings.pharmacy.model.vo.CoordinatesVO;
import com.rxsavings.pharmacy.repository.StoresRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.List;

@Service
public class NearestPharmacyServiceImpl implements NearestPharmacyService{

    @Autowired
    private StoresRepository storesRepository;

    @Override
    public NearestPharmacyDTO findNearestPharmacy(CoordinatesVO coordinatesVO) {

        if(coordinatesVO == null) return null;

        List<NearestPharmacyEntity> nearestPharmacyEntities = (List) storesRepository.findAll();
        return null;
    }


}
