package com.rxsavings.pharmacy.model.dto;

import lombok.Data;

@Data
public class NearestPharmacyDTO {
}
