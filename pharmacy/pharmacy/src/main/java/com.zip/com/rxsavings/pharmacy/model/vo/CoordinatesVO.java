package com.rxsavings.pharmacy.model.vo;

import lombok.Data;

@Data
public class CoordinatesVO {

    private String latitude;
    private String longitude;
}
