package com.rxsavings.pharmacy.model.vo;

import lombok.Data;

@Data
public class NearestPharmacyVO {
}
